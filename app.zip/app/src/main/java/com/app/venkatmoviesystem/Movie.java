package com.app.venkatmoviesystem;

import java.io.Serializable;

public class Movie implements Serializable {
     String name;
     String description;
     String certification;
     String image;
     String starring;
     String running_time_mins;
     int seats_remaining;
     int seats_selected;

    public Movie(String name, String description, String certification, String image, String starring, String running_time_mins, int seats_remaining, int seats_selected) {
        this.name = name;
        this.description = description;
        this.certification = certification;
        this.image = image;
        this.starring = starring;
        this.running_time_mins = running_time_mins;
        this.seats_remaining = seats_remaining;
        this.seats_selected = seats_selected;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getStarring() {
        return starring;
    }

    public void setStarring(String starring) {
        this.starring = starring;
    }

    public String getRunning_time_mins() {
        return running_time_mins;
    }

    public void setRunning_time_mins(String running_time_mins) {
        this.running_time_mins = running_time_mins;
    }

    public int getSeats_remaining() {
        return seats_remaining;
    }

    public void setSeats_remaining(int seats_remaining) {
        this.seats_remaining = seats_remaining;
    }

    public int getSeats_selected() {
        return seats_selected;
    }

    public void setSeats_selected(int seats_selected) {
        this.seats_selected = seats_selected;
    }
}
